﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace MCase
{
    public class MCasee
    {
        public string TopicName(string a)
        {
            if (a.Length <= 1)
            {
                return "Проверьте правильность ввода название темы";
            }
            if (a.Length == 1)
            {
                return "Проверьте правильность ввода название темы";
            }
            return "Тема успешно добавлена!";
        }

        public string AdminCode(string a)
        {
            if (a == "admin")
            {
                return a;
            }
            else return "Проверьте правильность ввода кода админа";
        }

        public string AddPost(string a)
        {
            if (a.Length == 0)
            {
                return "Поле не может быть пустым";
            }
            return "Должность успешно добавлена";
        }

        public string AddClass(string a)
        {
            if (a.Length == 4)
            {
                try
                {
                    Convert.ToInt32(a);
                    return "Класс успешно добавлен!";
                }
                catch { return "Номер класса должно состоять из 4 цифр (Например : 1233)"; }
            }
            else return "Номер класса должно состоять из 4 цифр (Например : 1233)";
        }

        public string Autorization(string log, string pass)
        {
            if (log == "teach" & pass == "teach")
            {
                return "Успешно";
            }
            return "Неверный логин или пароль";
        }
       
        public string TeachersFIO(string Surname, string Name, string Middlename)
        {
            string FIO;
            if (Surname.Length > 0 & Name.Length > 0 & Middlename.Length > 0) { FIO = Surname + " " + Name + " " + Middlename; return FIO; }
            //если нет отчества else if (Surname.Length > 0 & Name.Length > 0 & Middlename.Length == 0) { FIO = Surname + " " + Name; return FIO; }
            else return "Проверьте правильность ввода ФИО";
        }
    }
}
