﻿using System;
using MCase;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace MCaseTests
{
    [TestClass]
    public class MCaseTests
    {
        [TestMethod]
        public void CheckCorrectInput_TopicName()
        {
            string a = "Тема";
           
            string expected = "Тема успешно добавлена!";
            MCasee c = new MCasee();
            string actual = c.TopicName(a);
            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void InputAdminCode_Authorization()
        {
            string a = "admin";

            string expected = "admin";
            MCasee c = new MCasee();
            string actual = c.AdminCode(a);
            Assert.AreEqual(expected, actual);
        }
      
            [TestMethod]
        public void CheckCorrectInput_AddPost()
        {
            string a = "";

            string expected = "Должность успешно добавлена";
            MCasee c = new MCasee();
            string actual = c.AddPost(a);
            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void CheckCorrectInput_AddClass()
        {
            string a = "324";

            string expected = "Класс успешно добавлен";
            MCasee c = new MCasee();
            string actual = c.AddClass(a);
            Assert.AreEqual(expected, actual);
        }
       
        [TestMethod]
        public void CheckCorrectInput_Autorization()
        {
            string log = "teach";
            string pass = "324";
            string expected = "Успешно";
            MCasee c = new MCasee();
            string actual = c.Autorization(log,pass);
            Assert.AreEqual(expected, actual);
        }
       [TestMethod]
        public void CheckCorrectInput_TeachersFIO()
        {
            string Surname = "Иванов";
            string Name = "Иван";
            string Middlename = "Иванович";
            string expected = Surname + " " + Name + " " + Middlename;
                MCasee c = new MCasee();
                string actual = c.TeachersFIO(Surname, Name, Middlename);
                Assert.AreEqual(expected, actual);
            //Дописать еще надо
            //string Surname = "Иванов";
            //string Name = "";
            //string Middlename = "Алексеевич";
            //if (Middlename.Length > 0)
            //{
            //    string expected = Surname + " " + Name + " " + Middlename;
            //    MCasee c = new MCasee();
            //    string actual = c.TeachersFIO(Surname, Name, Middlename);
            //    Assert.AreEqual(expected, actual);
            //}
            //else if (Middlename.Length == 0)
            //{
            //    string expected = Surname + " " + Name;
            //    MCasee c = new MCasee();
            //    string actual = c.TeachersFIO(Surname, Name, Middlename);
            //    Assert.AreEqual(expected, actual);
            //}
            //else
            //{
            //    string expected = "Проверьте правильность ввода ФИО"; MCasee c = new MCasee();
            //    string actual = c.TeachersFIO(Surname, Name, Middlename);
            //    Assert.AreEqual(expected, actual);
            //}


        }


    }
}
